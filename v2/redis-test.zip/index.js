const { createClient } = require('redis');
const fs = require('fs');

const timeIndex = new Date().getTime();
const STREAM_NAME = 'numbersStream' + timeIndex;
const GROUP_NAME = 'group' + timeIndex;
const NUMBER_RANGE = 100;
const NUM_PRODUCERS = 3;

const producerClient = createClient();
const consumerClient = createClient();

async function createStreamGroup() {
  try {
    await consumerClient.xGroupCreate(STREAM_NAME, GROUP_NAME, '$', {
      MKSTREAM: true,
    });
  } catch (error) {
    console.log('Группа уже существует или ошибка при создании группы:', error);
  }
}

function getRandomDigits(num) {
  const digits = Array.from({ length: num + 1 }, (_, i) => i);

  for (let i = digits.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [digits[i], digits[j]] = [digits[j], digits[i]];
  }

  return digits;
}

async function producer() {
  const randomDigits = getRandomDigits(NUMBER_RANGE);

  for (let i = 0; i < randomDigits.length; i++) {
    const number = randomDigits[i];
    await producerClient.xAdd(STREAM_NAME, '*', { number: number.toString() });
    console.log(`Производитель добавил число: ${number}`);
  }
}

async function consumer() {
  const numbersSet = new Set();
  const startTime = Date.now();

  while (numbersSet.size < NUMBER_RANGE) {
    const result = await consumerClient.xReadGroup(
      GROUP_NAME,
      'consumer1',
      [{ key: STREAM_NAME, id: '>' }],
      { COUNT: 10, BLOCK: 1000 },
    );

    if (result && result[0]) {
      result[0].messages.forEach((message) => {
        const number = parseInt(message.message.number);
        if (!numbersSet.has(number)) {
          numbersSet.add(number);
          console.log(`Потребитель добавил число: ${number}`);
        }
      });
    }
  }

  const timeSpent = Date.now() - startTime;
  const result = {
    timeSpent,
    numbersGenerated: Array.from(numbersSet),
  };

  fs.writeFileSync('result.json', JSON.stringify(result, null, 2));
  console.log('Результаты записаны в result.json');
}

async function main() {
  await producerClient.connect();
  await consumerClient.connect();

  await createStreamGroup();

  const producers = [];
  for (let i = 0; i < NUM_PRODUCERS; i++) {
    producers.push(producer());
  }

  await Promise.all(producers);

  await consumer();

  await producerClient.quit();
  await consumerClient.quit();
}

main().catch((err) => {
  console.error('Произошла ошибка:', err);
});
